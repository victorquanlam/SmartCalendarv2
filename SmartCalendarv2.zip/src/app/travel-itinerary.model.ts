export class TravelItinerary {
    id: string;
    title: string;
    startsAt: string;
    endsAt: string;
  }
