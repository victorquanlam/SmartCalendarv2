export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyB9FgWueAc23WRmXqR-HhOsszPO1TQadA0',
    authDomain: 'smart-calendar-eb99c.firebaseapp.com',
    databaseURL: 'https://smart-calendar-eb99c.firebaseio.com',
    projectId: 'smart-calendar-eb99c',
    storageBucket: 'smart-calendar-eb99c.appspot.com',
    messagingSenderId: '86818688461',
    appId: '1:86818688461:web:bff4abecfac23a3b'
  }
};
