export class Upload {
}
