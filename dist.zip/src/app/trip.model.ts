
export class Trip {
    id: string;
    title: string;
    location: string;
    startsAt: any;
    endsAt: any;
    travelItinerary: String;
    users: any[];
    latitude:string;
    longitude:string;
  }
