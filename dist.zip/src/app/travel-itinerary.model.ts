export class TravelItinerary {
    id: string;
    title: string;
    startsAt: any;
    endsAt: any;
    users: any[];
  }
