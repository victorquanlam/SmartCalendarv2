
export class Expense {
    id: string;
    travelItinerary: String;
    staff: string;
    title: string;
    cost: number;
    attachmentId:string;
    downloadURL:string;
  }
