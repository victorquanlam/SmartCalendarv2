export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAix4OwaOHQWuiA7BMnwpMJj-VRzBtraKA",
    authDomain: "swinburnesmartcalendar.firebaseapp.com",
    databaseURL: "https://swinburnesmartcalendar.firebaseio.com",
    projectId: "swinburnesmartcalendar",
    storageBucket: "swinburnesmartcalendar.appspot.com",
    messagingSenderId: "958249816402",
    appId: "1:958249816402:web:6e20b36d91e3e6fd6eea8b",
    measurementId: "G-FQ0FKZSH4H"
  }
};
